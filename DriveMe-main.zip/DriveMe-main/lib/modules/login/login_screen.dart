import 'package:driveme/consts/colors.dart';
import 'package:driveme/consts/images.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

import '../../common/widgets/button_widget.dart';
import '../../common/widgets/header_widget.dart';
import '../../common/widgets/input_textfield.dart';
import '../home/home_screen.dart';
import '../signup/signup_screen.dart';
import 'controllers/login_controller.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(LoginController());
    return Scaffold(
      body: Column(
        children: [
          HeaderWidget(
            height: Get.height * 0.4,
            title: "Sign In",
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextFieldWidget(
                        controller: controller.phoneNumberController,
                        hintText: "Enter your phone number"),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                        controller: controller.phoneNumberController,
                        hintText: "Enter your password"),
                    const SizedBox(height: 20),
                    ButtonWidget(
                      onPressed: () {
                        Get.offAll(() => const HomeScreen());
                      },
                      title: "Sign In",
                    ),
                    SizedBox(height: 20),
                    GestureDetector(
                        onTap: () {
                          Get.off(() => const SignUpScreenScreen());
                        },
                        child: RichText(
                            text: TextSpan(
                          text: "Don't have an account? ",
                          style: TextStyle(color: Colors.black, fontSize: 18),
                          children: [
                            TextSpan(
                              text: "Sign Up",
                              style: TextStyle(
                                color: AppColor.green,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ))),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
