import 'package:driveme/common/widgets/button_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../common/widgets/back_widget.dart';
import '../../consts/colors.dart';
import '../home/home_screen.dart';
import 'widgets/booking_header_widget.dart';

class BookingConfirmScreen extends StatelessWidget {
  const BookingConfirmScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const BookingHeaderWidget(title: 'Booking Successful'),
          SizedBox(height: 20),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Your booking has been successfully placed. Please wait for the confirmation from the driver.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: 40),
                  ButtonWidget(
                    onPressed: () {
                      Get.offAll(() => HomeScreen());
                    },
                    padY: 15,
                    title: ('Back to Home'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
