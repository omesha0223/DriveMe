import 'package:driveme/common/widgets/button_widget.dart';
import 'package:driveme/common/widgets/header_widget.dart';
import 'package:driveme/consts/images.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../common/widgets/back_widget.dart';
import '../../consts/colors.dart';
import 'add_booking_screen.dart';
import 'widgets/booking_header_widget.dart';

class VehicleDetailsScreen extends StatelessWidget {
  const VehicleDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const BookingHeaderWidget(title: 'Vehicle Details'),
          SizedBox(height: 20),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                    height: 200,
                    width: double.infinity,
                    child: Image.asset(ImageConst.splash1)),
                SizedBox(height: 20),
                //vehicle details
                Text(
                  'Vehicle Details',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Vehicle Type: Toyota Prius',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Vehicle Number: ABC 123',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Vehicle Color: Black',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Number of Seats: 4',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Price: 1000 per km',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 20),
                //driver details
                Text(
                  'Driver Details',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Name: John Doe',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Phone: 1234567890',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
                SizedBox(height: 20),
                //button
                ButtonWidget(
                  title: 'Book Now',
                  padY: 15,
                  onPressed: () {
                    Get.to(() => AddBookingScreen());
                  },
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }
}
