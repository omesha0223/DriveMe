import 'package:driveme/common/widgets/button_widget.dart';
import 'package:driveme/common/widgets/input_textfield.dart';
import 'package:driveme/modules/booking/select_location_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../common/widgets/back_widget.dart';
import '../../consts/colors.dart';
import 'booking_confirmation_screen.dart';
import 'widgets/booking_header_widget.dart';

class AddBookingScreen extends StatelessWidget {
  const AddBookingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
      children: [
        BookingHeaderWidget(title: 'Vehicle Booking'),
        SizedBox(height: 20),
        Expanded(
            child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                TextFieldWidget(
                    controller: TextEditingController(), hintText: 'Name'),
                SizedBox(height: 20),
                TextFieldWidget(
                    controller: TextEditingController(), hintText: 'Phone'),
                SizedBox(height: 20),
                TextFieldWidget(
                    controller: TextEditingController(), hintText: 'No of Km'),
                SizedBox(height: 20),
                TextFieldWidget(
                  controller: TextEditingController(),
                  hintText: 'Start Location',
                  suffix: IconButton(
                    icon: Icon(
                      Icons.add_location,
                      size: 30,
                    ),
                    onPressed: () {
                      Get.to(() => SelectLocationScreen());
                    },
                  ),
                ),
                SizedBox(height: 20),
                TextFieldWidget(
                  controller: TextEditingController(),
                  hintText: 'End Location',
                  suffix: IconButton(
                    icon: Icon(
                      Icons.add_location,
                      size: 30,
                    ),
                    onPressed: () {
                      Get.to(() => SelectLocationScreen());
                    },
                  ),
                ),
                SizedBox(height: 20),
                TextFieldWidget(
                    controller: TextEditingController(),
                    hintText: 'Number of Passengers'),
                SizedBox(height: 20),
                TextFieldWidget(
                    controller: TextEditingController(), hintText: 'Date'),
                SizedBox(height: 30),
                ButtonWidget(
                    title: 'Book Now',
                    padY: 15,
                    onPressed: () {
                      Get.to(() => BookingConfirmScreen());
                    }),
              ],
            ),
          ),
        ))
      ],
    ));
  }
}
