import 'package:driveme/common/widgets/back_widget.dart';
import 'package:driveme/common/widgets/button_widget.dart';
import 'package:driveme/modules/booking/add_booking_screen.dart';
import 'package:driveme/modules/booking/vehicle_details_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../consts/colors.dart';
import '../../consts/images.dart';
import 'widgets/booking_header_widget.dart';

class SelectVehicleScreen extends StatelessWidget {
  const SelectVehicleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
      children: [
        const BookingHeaderWidget(title: 'Select a Vehicle'),
        SizedBox(height: 20),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.3),
                spreadRadius: 1,
                blurRadius: 2,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search for a vehicle',
                    border: InputBorder.none,
                  ),
                ),
              ),
              SizedBox(width: 10),
              Icon(Icons.search),
            ],
          ),
        ),
        SizedBox(height: 20),
        Expanded(
            child: GridView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.68,
          ),
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                Get.to(() => VehicleDetailsScreen());
              },
              child: Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 1,
                      blurRadius: 2,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Image.asset(
                      ImageConst.splash1,
                      height: 100,
                    ),
                    Text('Type: Caravan'),
                    Text('Price: \$100 per km'),
                    Text('Seats: 4'),
                    Text('Rating: 4.5'),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: ButtonWidget(
                          padY: 10,
                          title: 'Select',
                          onPressed: () {
                            Get.to(() => AddBookingScreen());
                          }),
                    ),
                  ],
                ),
              ),
            );
          },
          itemCount: 10,
        ))
      ],
    ));
  }
}
