import 'package:flutter/material.dart';

class RideHistoryWidget extends StatelessWidget {
  const RideHistoryWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20),
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Ride History',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
              child: ListView.builder(
                  itemCount: 5,
                  itemBuilder: ((context, index) {
                    return Card(
                      margin: EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: EdgeInsets.all(15),
                        child: Row(
                          children: [Text('Booking 1234')],
                        ),
                      ),
                    );
                  })))
        ],
      ),
    );
  }
}
