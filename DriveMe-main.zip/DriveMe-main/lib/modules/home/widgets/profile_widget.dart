import 'package:driveme/consts/images.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class ProfileWidget extends StatelessWidget {
  const ProfileWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Profile',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(height: 100, child: Image.asset(ImageConst.profile)),
            SizedBox(
              height: 10,
            ),
            Text(
              'Omesha Madumali',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            Divider(),
            ListTile(
              title: Text(
                'Payment History',
                style: TextStyle(fontSize: 18),
              ),
            ),
            ListTile(
              title: Text(
                'Invite Friends',
                style: TextStyle(fontSize: 18),
              ),
            ),
            ListTile(
              title: Text(
                'Promo Codes',
                style: TextStyle(fontSize: 18),
              ),
            ),
            ListTile(
              title: Text(
                'Support',
                style: TextStyle(fontSize: 18),
              ),
            ),
            ListTile(
              title: Text(
                'Settings',
                style: TextStyle(fontSize: 18),
              ),
            ),
            ListTile(
              title: Text(
                'Logout',
                style: TextStyle(fontSize: 18),
              ),
            )
          ],
        ),
      ),
    );
  }
}
