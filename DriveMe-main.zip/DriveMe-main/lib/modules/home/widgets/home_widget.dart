import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/button_widget.dart';
import '../../../consts/colors.dart';
import '../../booking/select_vehicle_screen.dart';

class HomeWidget extends StatelessWidget {
  const HomeWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Select your service today',
              style: TextStyle(
                fontSize: 20,
              )),
          const SizedBox(height: 40),
          ButtonWidget(
            title: 'Long Trip',
            onPressed: () {
              Get.to(() => const SelectVehicleScreen());
            },
            bgColor: AppColor.grey,
            textColor: Colors.black,
          ),
          const SizedBox(height: 20),
          ButtonWidget(
            title: 'Wedding Reservation',
            onPressed: () {
              Get.to(() => const SelectVehicleScreen());
            },
            bgColor: AppColor.grey,
            textColor: Colors.black,
          ),
        ],
      ),
    );
  }
}
