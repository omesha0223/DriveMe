import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  RxInt currentIndex = 0.obs;
  PageController? controller;

  changePage(index) {
    currentIndex.value = index;
    controller!.animateToPage(index,
        duration: Duration(milliseconds: 200), curve: Curves.linear);
  }

  @override
  void onInit() {
    controller = PageController(initialPage: 0);
    super.onInit();
  }
}
