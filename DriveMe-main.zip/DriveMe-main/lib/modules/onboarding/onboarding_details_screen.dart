import 'package:driveme/consts/colors.dart';
import 'package:driveme/consts/images.dart';
import 'package:driveme/modules/login/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../home/home_screen.dart';
import 'controllers/onboarding_controller.dart';

class OnboardingDetailsScreen extends StatelessWidget {
  const OnboardingDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(OnboardingController());
    return Scaffold(
      body: Obx(() {
        return Stack(
          children: [
            Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: Get.height * 0.4,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(ImageConst.splashBottom),
                      fit: BoxFit.fill,
                    ),
                  ),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20, top: 30),
                      child: Text(
                        controller.onboardingData[controller.currentIndex.value]
                            ['des'],
                        style: TextStyle(
                          fontSize: 25,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                )),
            Positioned(
                top: 0,
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: () {
                    if (controller.currentIndex.value ==
                        controller.onboardingData.length - 1) {
                      Get.offAll(() => const LoginScreen());
                    } else {
                      controller.currentIndex.value++;
                    }
                  },
                  child: Image.asset(
                    ImageConst.splashLine,
                  ),
                )),
            Positioned(
                top: 50,
                left: 20,
                right: 100,
                child: SafeArea(
                  child: Column(
                    children: [
                      Image.asset(
                        ImageConst.splashLogo,
                        height: 80,
                      ),
                      const SizedBox(height: 20),
                      Image.asset(
                        controller.onboardingData[controller.currentIndex.value]
                            ['image'],
                        height: 150,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        controller.onboardingData[controller.currentIndex.value]
                            ['title'],
                        style: TextStyle(
                          fontSize: 35,
                          color: AppColor.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        controller.onboardingData[controller.currentIndex.value]
                            ['subtitle'],
                        style: TextStyle(
                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                )),
          ],
        );
      }),
    );
  }
}
