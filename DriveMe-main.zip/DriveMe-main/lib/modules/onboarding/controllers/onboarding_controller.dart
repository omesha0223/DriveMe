import 'package:driveme/consts/images.dart';
import 'package:get/get.dart';

class OnboardingController extends GetxController {
  RxInt currentIndex = 0.obs;
  RxList onboardingData = [
    {
      'image': ImageConst.splash1,
      'title': 'Endless',
      'subtitle': 'Journeys',
      'des': 'Discover,\nbook, \nand ride \nhassle-free'
    },
    {
      'image': ImageConst.splash2,
      'title': 'Elevate',
      'subtitle': 'Your Travels',
      'des': 'Access \ntop-notch \nvehicles and \nexpert guidance'
    },
    {
      'image': ImageConst.splash3,
      'title': 'Your Journey',
      'subtitle': 'Starts Here',
      'des': 'A trusted \ncommunity \nfor car rentals \nin Sri Lanka.'
    },
  ].obs;
}
