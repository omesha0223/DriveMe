import 'package:driveme/consts/images.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'onboarding_details_screen.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Image.asset(
                ImageConst.splashBottom,
                height: Get.height * 0.5,
                fit: BoxFit.fill,
              )),
          Positioned(
              top: 0,
              bottom: 0,
              right: 0,
              child: GestureDetector(
                onTap: () {
                  Get.to(() => const OnboardingDetailsScreen());
                },
                child: Image.asset(
                  ImageConst.splashLine,
                ),
              )),
          Positioned(
              top: 0,
              bottom: 150,
              left: 40,
              right: 100,
              child: Image.asset(
                ImageConst.splashLogo,
              )),
        ],
      ),
    );
  }
}
