import 'package:driveme/common/widgets/button_widget.dart';
import 'package:driveme/common/widgets/header_widget.dart';
import 'package:driveme/consts/colors.dart';
import 'package:driveme/modules/home/home_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'driver/vehicle_photo_screen.dart';

class LoginOptionsScreen extends StatelessWidget {
  const LoginOptionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          HeaderWidget(
              height: Get.height * 0.3,
              title: "Select Role",
              logoEnabled: false,
              backEnabled: true),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ButtonWidget(
                    onPressed: () {
                      Get.to(() => const VehiclePhotoScreen());
                    },
                    title: ("Sign Up as Driver"),
                    bgColor: AppColor.grey,
                    textColor: Colors.black,
                  ),
                  const SizedBox(height: 40),
                  ButtonWidget(
                    onPressed: () {
                      Get.offAll(() => const HomeScreen());
                    },
                    title: ("Sign Up as User"),
                    bgColor: AppColor.grey,
                    textColor: Colors.black,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
