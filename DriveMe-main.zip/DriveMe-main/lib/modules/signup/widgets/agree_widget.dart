import 'package:flutter/material.dart';

class AgreeWidget extends StatelessWidget {
  const AgreeWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return RichText(
        textAlign: TextAlign.center,
        text: TextSpan(
          text: "By creating and account, you agree to our ",
          style: TextStyle(color: Colors.black, fontSize: 15),
          children: [
            TextSpan(
              text: "Terms & Conditions",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextSpan(
              text: " and ",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            TextSpan(
              text: "Privacy Policy",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ));
  }
}
