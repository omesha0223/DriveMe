import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';

class SignUpController extends GetxController {
  var phoneNumberController = TextEditingController();
 

}
