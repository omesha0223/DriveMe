import 'package:driveme/consts/colors.dart';
import 'package:driveme/consts/images.dart';
import 'package:driveme/modules/home/home_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

import '../../../common/widgets/header_widget.dart';

class RegistrationCompleteScreen extends StatelessWidget {
  const RegistrationCompleteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          HeaderWidget(
              height: Get.height * 0.3,
              title: 'Registration Complete',
              logoEnabled: false,
              backEnabled: true),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'You successfully registered on',
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Image.asset(ImageConst.splashLogo),
                  const SizedBox(height: 40),
                  Text(
                    'Your DriveMe ID',
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'DRM-123456',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          GestureDetector(
              onTap: () {
                Get.offAll(() => const HomeScreen());
              },
              child: Image.asset(ImageConst.bottomBar)),
          Container(
            height: 10,
            color: AppColor.green,
          )
        ],
      ),
    );
  }
}
