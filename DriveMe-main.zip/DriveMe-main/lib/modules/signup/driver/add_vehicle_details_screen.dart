import 'package:driveme/common/widgets/button_widget.dart';
import 'package:driveme/common/widgets/input_textfield.dart';
import 'package:driveme/modules/signup/driver/registration_complete_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/header_widget.dart';
import '../../../consts/images.dart';

class AddVehicleDetailsScreen extends StatelessWidget {
  const AddVehicleDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          HeaderWidget(
            logoEnabled: false,
            height: Get.height * 0.3,
            title: 'Vehicle Details',
            backEnabled: true,
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter vehicle registration number',
                    ),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter vehicle type',
                    ),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter no of seats',
                    ),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter fee per km',
                    ),
                    const SizedBox(height: 40),
                    // button
                    ButtonWidget(
                        title: 'Submit',
                        onPressed: () {
                          Get.offAll(() => const RegistrationCompleteScreen());
                        }),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
