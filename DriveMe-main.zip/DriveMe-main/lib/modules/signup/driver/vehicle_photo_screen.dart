import 'package:driveme/modules/signup/driver/add_vehicle_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/header_widget.dart';
import '../../../consts/images.dart';

class VehiclePhotoScreen extends StatelessWidget {
  const VehiclePhotoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          HeaderWidget(
            logoEnabled: false,
            height: Get.height * 0.3,
            title: 'Vehicle Registration',
            backEnabled: true,
          ),
          Expanded(
              child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Upload a photo of your vehicle number plate',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    height: 200,
                    width: Get.width,
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Image.asset(
                        ImageConst.camera,
                        height: 50,
                        width: 50,
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Upload 4 photos of your vehicle',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
                  ),

                  // grid view
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                    ),
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 200,
                        width: Get.width * 0.4,
                        decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Image.asset(
                            ImageConst.camera,
                            height: 50,
                            width: 50,
                            fit: BoxFit.fill,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  // button
                  Center(
                      child: GestureDetector(
                    onTap: () {
                      Get.to(() => const AddVehicleDetailsScreen());
                    },
                    child: Image.asset(ImageConst.forward,
                        height: 100, width: 100),
                  )),
                ],
              ),
            ),
          ))
        ],
      ),
    );
  }
}
