import 'package:driveme/common/widgets/button_widget.dart';
import 'package:driveme/common/widgets/header_widget.dart';
import 'package:driveme/common/widgets/input_textfield.dart';
import 'package:driveme/consts/images.dart';
import 'package:driveme/modules/signup/login_options_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CreateProfileScreen extends StatelessWidget {
  const CreateProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 60),
                child: HeaderWidget(
                    logoEnabled: false,
                    height: Get.height * 0.3,
                    title: 'Create Your Profile'),
              ),
              Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Center(
                      child: Container(
                    height: 120,
                    width: 120,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(ImageConst.circleAvatar),
                        fit: BoxFit.fill,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Image.asset(
                        ImageConst.camera,
                        height: 50,
                        width: 50,
                        fit: BoxFit.fill,
                      ),
                    ),
                  ))),
            ],
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter your first name',
                    ),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter your last name',
                    ),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter your email',
                    ),
                    const SizedBox(height: 20),
                    TextFieldWidget(
                      controller: TextEditingController(),
                      hintText: 'Enter your password',
                    ),
                    const SizedBox(height: 20),
                    Center(
                        child: GestureDetector(
                      onTap: () {
                        Get.to(() => const LoginOptionsScreen());
                      },
                      child: Image.asset(ImageConst.forward,
                          height: 100, width: 100),
                    )),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
