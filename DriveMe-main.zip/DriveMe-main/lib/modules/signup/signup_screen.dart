import 'package:driveme/consts/images.dart';
import 'package:driveme/modules/login/login_screen.dart';
import 'package:driveme/modules/signup/otp_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../common/widgets/button_widget.dart';
import '../../common/widgets/header_widget.dart';
import '../../common/widgets/input_textfield.dart';
import '../../consts/colors.dart';
import 'controllers/signup_controller.dart';
import 'widgets/agree_widget.dart';

class SignUpScreenScreen extends StatelessWidget {
  const SignUpScreenScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(SignUpController());
    return Scaffold(
      body: Column(
        children: [
          HeaderWidget(
            height: Get.height * 0.4,
            title: "Sign Up",
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                      "Hello, nice to meet you !",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Get Moving With DriveMe",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 30),
                    TextFieldWidget(
                        prefix: Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 50,
                                child: Image.asset(
                                  ImageConst.srilanka,
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                              Text("+94",
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 16)),
                            ],
                          ),
                        ),
                        controller: controller.phoneNumberController,
                        hintText: "Enter your mobile number"),
                    const SizedBox(height: 30),
                    const AgreeWidget(),
                    const SizedBox(height: 20),
                    ButtonWidget(
                      title: "Verify Number",
                      onPressed: () {
                        Get.to(() => const OtpScreenScreen());
                      },
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      onTap: () {
                        Get.off(() => const LoginScreen());
                      },
                      child: RichText(
                        text: TextSpan(
                          text: "Already have an account? ",
                          style: TextStyle(color: Colors.black, fontSize: 18),
                          children: [
                            TextSpan(
                              text: "Sign In",
                              style: TextStyle(
                                color: AppColor.green,
                                fontSize: 18,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
