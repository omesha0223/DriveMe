import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../../consts/colors.dart';
import '../../consts/images.dart';
import 'back_widget.dart';

class HeaderWidget extends StatelessWidget {
  final bool? logoEnabled;
  final bool? backEnabled;
  final double height;
  final String title;
  final double? titleBottomPadding;
  const HeaderWidget(
      {super.key,
      required this.height,
      required this.title,
      this.logoEnabled = true,
      this.backEnabled = false,
      this.titleBottomPadding = 0.0});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(100),
          bottomRight: Radius.circular(100),
        ),
        color: AppColor.green,
      ),
      child: Align(
        alignment: Alignment.center,
        child: Padding(
          padding: const EdgeInsets.only(left: 20, top: 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (backEnabled!)
                Align(
                    alignment: Alignment.topLeft,
                    child: const SafeArea(child: BackWidget())),
              if (backEnabled!) Spacer(),
              if (logoEnabled!)
                Image.asset(
                  ImageConst.splashLogo,
                  height: 100,
                  color: Colors.white,
                ),
              Text(
                title,
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: titleBottomPadding),
              if (backEnabled!) Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}
