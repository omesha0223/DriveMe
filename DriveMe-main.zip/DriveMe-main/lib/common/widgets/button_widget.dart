import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../consts/colors.dart';

class ButtonWidget extends StatelessWidget {
  final String title;
  final VoidCallback onPressed;
  final Color? bgColor;
  final Color? textColor;
  final double? padX;
  final double? padY;
  const ButtonWidget(
      {super.key,
      required this.title,
      required this.onPressed,
      this.bgColor,
      this.textColor,
      this.padX = 0,
      this.padY = 15});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: Get.width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 1,
            blurRadius: 2,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          elevation: 5,
          backgroundColor: bgColor ?? AppColor.green,
          foregroundColor: textColor ?? Colors.white,
          padding: EdgeInsets.symmetric(horizontal: padX!, vertical: padY!),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        child: Text(title, style: const TextStyle(fontSize: 20)),
      ),
    );
  }
}
