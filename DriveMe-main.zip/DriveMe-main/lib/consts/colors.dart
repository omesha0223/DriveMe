import 'package:flutter/material.dart';

class AppColor {
  static Color green = const Color(0xFF007F20);
  static Color darkgreen = const Color(0xFF3BEE2C);
  static Color grey = const Color(0xFFD9D9D9);
}
