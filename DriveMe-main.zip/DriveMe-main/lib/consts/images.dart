class ImageConst {
  static const String splashLogo = 'assets/images/logo.png';
  static const String splash1 = 'assets/images/splash-1.png';
  static const String splash2 = 'assets/images/splash-2.png';
  static const String splash3 = 'assets/images/splash-3.png';
  static const String splashLine = 'assets/images/splash-line.png';
  static const String splashBottom = 'assets/images/splash-bottom.png';
  static const String forward = 'assets/images/forward.png';
  static const String circleAvatar = 'assets/images/circle.png';
  static const String camera = 'assets/images/camera.png';
  static const String srilanka = 'assets/images/srilanka.png';
  static const String homeIcon = 'assets/images/home.png';
  static const String bottomBar = 'assets/images/bottom-bar.png';
  static const String profile = 'assets/images/profile.png';
  static const String back = 'assets/images/back.png';
}
